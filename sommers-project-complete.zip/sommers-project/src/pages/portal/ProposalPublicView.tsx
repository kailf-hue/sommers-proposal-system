/**
 * ProposalPublicView Page
 */

export default function ProposalPublicView() {
  return (
    <div className="min-h-screen bg-gray-50">
      <h1 className="text-2xl font-bold">ProposalPublicView</h1>
    </div>
  );
}
