/**
 * PaymentPage Page
 */

export default function PaymentPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <h1 className="text-2xl font-bold">PaymentPage</h1>
    </div>
  );
}
