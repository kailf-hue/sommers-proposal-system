/**
 * ClientPortal Page
 */

export default function ClientPortal() {
  return (
    <div className="min-h-screen bg-gray-50">
      <h1 className="text-2xl font-bold">ClientPortal</h1>
    </div>
  );
}
