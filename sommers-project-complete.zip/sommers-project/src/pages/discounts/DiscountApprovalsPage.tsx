/**
 * DiscountApprovalsPage
 */

export default function DiscountApprovalsPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">DiscountApprovalsPage</h1>
    </div>
  );
}
