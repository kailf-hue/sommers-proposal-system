/**
 * DiscountCodesPage
 */

export default function DiscountCodesPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">DiscountCodesPage</h1>
    </div>
  );
}
