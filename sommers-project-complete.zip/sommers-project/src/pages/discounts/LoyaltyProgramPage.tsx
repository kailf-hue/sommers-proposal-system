/**
 * LoyaltyProgramPage
 */

export default function LoyaltyProgramPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">LoyaltyProgramPage</h1>
    </div>
  );
}
