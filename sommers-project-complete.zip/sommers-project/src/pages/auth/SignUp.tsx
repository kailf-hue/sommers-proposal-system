/**
 * SignUp Page
 */

export default function SignUp() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50">
      <div className="w-full max-w-md p-8">
        <h1 className="text-2xl font-bold text-center">SignUp</h1>
      </div>
    </div>
  );
}
