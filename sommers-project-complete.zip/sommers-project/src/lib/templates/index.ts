export * from './templatesService';
