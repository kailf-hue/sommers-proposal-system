export { getBrandingSettings, getWhiteLabelConfig, updateWhiteLabelConfig } from '@/lib/branding';
